# Fiscal tools

These tools resolve different issues for developments that require reports for regulatory entities in Argentina.
